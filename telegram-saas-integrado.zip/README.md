# 🚀 Telegram SaaS Pro v4

Sistema profissional de gerenciamento multi-conta para Telegram com interface web moderna e API REST completa.

## ✨ Funcionalidades

### 🎯 **Core Features**
- **Multi-Account Management** - Gerencie múltiplas contas Telegram simultaneamente
- **Real-time Dashboard** - Estatísticas e gráficos interativos em tempo real
- **Individual Webhooks** - Webhook personalizado para cada conta conectada
- **Message Broadcasting** - Envio de mensagens para múltiplos chats
- **Media Support** - Envio de fotos, vídeos e áudios
- **API REST** - 16 endpoints documentados para integração

### 🔧 **Technical Features**
- **Modern UI** - Interface responsiva com design profissional
- **Session Management** - Sessões persistentes do Telegram
- **Error Handling** - Tratamento robusto de erros e logs detalhados
- **Auto-reconnect** - Reconexão automática em caso de falhas
- **Security** - Validação de dados e proteção contra ataques

## 🚀 Instalação Rápida

### Via GitHub (Recomendado)
```bash
curl -fsSL https://raw.githubusercontent.com/Lucasfig199/TEL-SAAS-3.0/main/install.sh | bash
```

### Instalação Manual
```bash
# 1. Baixar projeto
git clone https://github.com/Lucasfig199/TEL-SAAS-3.0.git
cd TEL-SAAS-3.0

# 2. Executar instalação
./install.sh

# 3. Iniciar sistema
./run.sh
```

## 🎯 Como Usar

### 1. **Iniciar Sistema**
```bash
cd telegram-saas-integrado
./run.sh
```

### 2. **Acessar Interface**
- **Local**: http://localhost:5000
- **Externo**: http://SEU_IP:5000

### 3. **Conectar Conta**
1. Acesse a aba "Conectar Conta"
2. Obtenha API ID e Hash em: https://my.telegram.org
3. Digite telefone, API ID e API Hash
4. Digite o código de verificação recebido

### 4. **Configurar Webhooks**
1. Acesse "Gerenciar Contas"
2. Clique em "Editar" no webhook da conta
3. Digite a URL do seu webhook
4. Clique em "Salvar"

## 📚 API Endpoints

### 🔗 **Gerenciamento de Contas**
- `GET /api/accounts` - Listar contas conectadas
- `POST /api/connect-account` - Conectar nova conta
- `POST /api/verify-code` - Verificar código SMS
- `DELETE /api/remove-account` - Remover conta

### 📤 **Envio de Mensagens**
- `POST /api/send-message` - Enviar mensagem de texto
- `POST /api/send-photo` - Enviar foto
- `POST /api/send-video` - Enviar vídeo
- `POST /api/send-audio` - Enviar áudio

### 🔗 **Webhooks**
- `POST /api/set-webhook` - Configurar webhook individual
- `GET /api/webhooks` - Listar webhooks configurados

### 📊 **Sistema**
- `GET /api/status` - Status do sistema e estatísticas
- `GET /api/logs` - Logs do sistema

## 🔧 Comandos Úteis

```bash
# Iniciar sistema
./run.sh

# Parar sistema
Ctrl+C
# ou
pkill -f telegram_api

# Ver logs
tail -f nohup.out

# Status da API
curl http://localhost:5000/api/status

# Listar contas
curl http://localhost:5000/api/accounts

# Liberar firewall (acesso externo)
ufw allow 5000
```

## 🛠️ Estrutura do Projeto

```
telegram-saas-integrado/
├── telegram_api_v4.py      # Backend principal
├── static/
│   └── index.html          # Interface web
├── requirements.txt        # Dependências Python
├── install.sh             # Script de instalação
├── run.sh                 # Script de execução
├── accounts.json          # Contas conectadas
├── webhooks.json          # Webhooks configurados
├── config.json            # Configurações gerais
├── scheduled_messages.json # Mensagens agendadas
└── README.md              # Esta documentação
```

## 🔒 Segurança

- **Sessões Criptografadas** - Arquivos .session protegidos
- **Validação de Dados** - Todos os inputs são validados
- **Rate Limiting** - Proteção contra spam
- **Error Handling** - Logs detalhados sem exposição de dados sensíveis

## 🐛 Troubleshooting

### Problema: Porta já em uso
```bash
pkill -f telegram_api
./run.sh
```

### Problema: Dependências não instaladas
```bash
source venv/bin/activate
pip install -r requirements.txt
```

### Problema: Conta não conecta
1. Verifique API ID e Hash em my.telegram.org
2. Certifique-se que o número está correto (+55...)
3. Verifique se recebeu o código no Telegram

### Problema: Interface não carrega
```bash
# Verificar se o arquivo HTML existe
ls -la static/index.html

# Testar acesso direto
curl http://localhost:5000/
```

## 📞 Suporte

Para problemas ou dúvidas:
1. Verifique os logs: `tail -f nohup.out`
2. Teste a API: `curl http://localhost:5000/api/status`
3. Reinicie o sistema: `./run.sh`

## 📄 Licença

Este projeto é de uso livre para fins educacionais e comerciais.

---

**Desenvolvido com ❤️ para automação profissional do Telegram**

