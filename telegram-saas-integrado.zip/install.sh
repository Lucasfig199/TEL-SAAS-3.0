#!/bin/bash

# Telegram SaaS Pro v4 - Script de Instalação
# Versão: 4.0 Final
# Data: 10/08/2025

set -e  # Parar em caso de erro

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Funções de log
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

log_header() {
    echo -e "${PURPLE}🚀 $1${NC}"
    echo "===================================="
}

# Header
clear
log_header "Telegram SaaS Pro v4 - Instalação"

# 1. Atualizar sistema
log_info "1/8 Atualizando sistema..."
if command -v apt-get &> /dev/null; then
    apt-get update -y > /dev/null 2>&1 || log_warning "Falha na atualização do sistema"
elif command -v yum &> /dev/null; then
    yum update -y > /dev/null 2>&1 || log_warning "Falha na atualização do sistema"
fi
log_success "Sistema atualizado"

# 2. Instalar dependências do sistema
log_info "2/8 Instalando dependências do sistema..."
if command -v apt-get &> /dev/null; then
    apt-get install -y python3 python3-pip python3-venv curl wget unzip > /dev/null 2>&1 || {
        log_warning "Tentando instalação individual..."
        apt-get install -y python3 || true
        apt-get install -y python3-pip || true
        apt-get install -y python3-venv || true
        apt-get install -y curl || true
        apt-get install -y wget || true
        apt-get install -y unzip || true
    }
elif command -v yum &> /dev/null; then
    yum install -y python3 python3-pip curl wget unzip > /dev/null 2>&1 || {
        log_warning "Tentando instalação individual..."
        yum install -y python3 || true
        yum install -y python3-pip || true
        yum install -y curl || true
        yum install -y wget || true
        yum install -y unzip || true
    }
fi
log_success "Dependências do sistema instaladas"

# 3. Verificar Python
log_info "3/8 Verificando Python..."
if command -v python3 &> /dev/null; then
    PYTHON_VERSION=$(python3 --version 2>&1)
    log_success "Python encontrado: $PYTHON_VERSION"
else
    log_error "Python3 não encontrado!"
    exit 1
fi

# 4. Verificar pip3
log_info "4/8 Verificando pip3..."
if command -v pip3 &> /dev/null; then
    log_success "pip3 encontrado"
else
    log_warning "pip3 não encontrado, tentando instalar..."
    if command -v apt-get &> /dev/null; then
        apt-get install -y python3-pip
    elif command -v yum &> /dev/null; then
        yum install -y python3-pip
    fi
fi

# 5. Criar ambiente virtual
log_info "5/8 Criando ambiente virtual..."
if [ ! -d "venv" ]; then
    python3 -m venv venv || {
        log_warning "Falha ao criar venv, tentando alternativa..."
        python3 -m pip install --user virtualenv
        python3 -m virtualenv venv
    }
fi
log_success "Ambiente virtual criado"

# 6. Ativar ambiente virtual
log_info "6/8 Ativando ambiente virtual..."
source venv/bin/activate
log_success "Ambiente virtual ativado"

# 7. Instalar dependências Python
log_info "7/8 Instalando dependências Python..."
pip install --upgrade pip > /dev/null 2>&1 || log_warning "Falha ao atualizar pip"

# Instalar uma por vez para melhor controle
PACKAGES=("flask" "telethon" "requests" "python-dotenv" "asyncio")
for package in "${PACKAGES[@]}"; do
    log_info "Instalando $package..."
    pip install "$package" > /dev/null 2>&1 || log_warning "Falha ao instalar $package"
done

log_success "Dependências Python instaladas"

# 8. Verificar instalação
log_info "8/8 Verificando instalação..."

# Testar importações
python3 -c "
import flask
import telethon
import requests
import json
import os
print('✅ Todas as bibliotecas importadas com sucesso')
" || {
    log_error "Erro na verificação das bibliotecas"
    exit 1
}

# Verificar arquivo principal
if [ -f "telegram_api_v4.py" ]; then
    python3 -m py_compile telegram_api_v4.py || {
        log_error "Erro na sintaxe do arquivo principal"
        exit 1
    }
    log_success "Arquivo principal válido"
else
    log_error "Arquivo telegram_api_v4.py não encontrado!"
    exit 1
fi

# Verificar arquivos JSON
for file in accounts.json webhooks.json config.json scheduled_messages.json; do
    if [ ! -f "$file" ]; then
        log_warning "Arquivo $file não encontrado, criando..."
        case $file in
            "accounts.json") echo '[]' > "$file" ;;
            "webhooks.json") echo '{}' > "$file" ;;
            "config.json") echo '{"webhook_url": ""}' > "$file" ;;
            "scheduled_messages.json") echo '[]' > "$file" ;;
        esac
    fi
done

# Verificar diretório static
if [ ! -d "static" ]; then
    log_warning "Diretório static não encontrado, criando..."
    mkdir -p static
fi

if [ ! -f "static/index.html" ]; then
    log_error "Arquivo static/index.html não encontrado!"
    exit 1
fi

log_success "Verificação concluída"

# Finalização
echo ""
log_header "INSTALAÇÃO CONCLUÍDA COM SUCESSO!"
echo ""
log_success "Telegram SaaS Pro v4 instalado e 100% funcional!"
echo ""
echo -e "${CYAN}📋 PRÓXIMOS PASSOS:${NC}"
echo "1. cd $(pwd)"
echo "2. ./run.sh"
echo "3. Acesse: http://localhost:5000"
echo "4. Conecte suas contas na aba 'Conectar Conta'"
echo "5. Configure webhooks na aba 'Gerenciar Contas'"
echo ""
echo -e "${CYAN}🔧 COMANDOS ÚTEIS:${NC}"
echo "• Iniciar: ./run.sh"
echo "• Parar: Ctrl+C ou pkill -f telegram_api"
echo "• Logs: tail -f nohup.out"
echo "• Status: curl http://localhost:5000/api/status"
echo ""
echo -e "${CYAN}🌐 ACESSO EXTERNO (se necessário):${NC}"
echo "• Liberar firewall: ufw allow 5000"
echo "• Acesso externo: http://SEU_IP_VPS:5000"
echo ""
log_info "Sistema instalado em: $(pwd)"
echo ""
echo -e "${GREEN}🎉 Para iniciar agora mesmo:${NC}"
echo -e "${YELLOW}cd $(pwd) && ./run.sh${NC}"

