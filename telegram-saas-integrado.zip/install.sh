#!/bin/bash

# Telegram SaaS Pro v4 - Instalador Automático
# Versão: 4.0 Clean
# Data: $(date)

set -e  # Parar em caso de erro

echo "🚀 Telegram SaaS Pro v4 - Instalador Automático"
echo "================================================"
echo ""

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Função para log colorido
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Verificar se está rodando como root
if [[ $EUID -eq 0 ]]; then
   log_warning "Este script não deve ser executado como root"
   log_info "Execute como usuário normal: ./install.sh"
   exit 1
fi

# Verificar sistema operacional
if [[ "$OSTYPE" != "linux-gnu"* ]]; then
    log_error "Este instalador é compatível apenas com Linux"
    exit 1
fi

log_info "Iniciando instalação do Telegram SaaS Pro v4..."
echo ""

# 1. Atualizar sistema
log_info "1/8 Atualizando sistema..."
sudo apt update -qq > /dev/null 2>&1
log_success "Sistema atualizado"

# 2. Instalar dependências do sistema
log_info "2/8 Instalando dependências do sistema..."
sudo apt install -y python3 python3-pip python3-venv curl wget unzip > /dev/null 2>&1
log_success "Dependências do sistema instaladas"

# 3. Verificar Python
log_info "3/8 Verificando Python..."
if ! command -v python3 &> /dev/null; then
    log_error "Python3 não encontrado"
    exit 1
fi

PYTHON_VERSION=$(python3 --version | cut -d' ' -f2 | cut -d'.' -f1,2)
log_success "Python $PYTHON_VERSION encontrado"

# 4. Criar ambiente virtual
log_info "4/8 Criando ambiente virtual..."
if [ ! -d "venv" ]; then
    python3 -m venv venv
    log_success "Ambiente virtual criado"
else
    log_warning "Ambiente virtual já existe"
fi

# 5. Ativar ambiente virtual e instalar dependências Python
log_info "5/8 Instalando dependências Python..."
source venv/bin/activate

# Atualizar pip
pip install --upgrade pip > /dev/null 2>&1

# Instalar dependências uma por uma para melhor controle de erro
log_info "   Instalando Flask..."
pip install Flask==2.3.3 > /dev/null 2>&1

log_info "   Instalando Telethon..."
pip install Telethon==1.29.3 > /dev/null 2>&1

log_info "   Instalando requests..."
pip install requests==2.31.0 > /dev/null 2>&1

log_success "Dependências Python instaladas"

# 6. Verificar arquivos necessários
log_info "6/8 Verificando arquivos do projeto..."

REQUIRED_FILES=(
    "telegram_api_v4.py"
    "static/index.html"
    "accounts.json"
    "webhooks.json"
    "config.json"
    "scheduled_messages.json"
)

for file in "${REQUIRED_FILES[@]}"; do
    if [ ! -f "$file" ]; then
        log_error "Arquivo necessário não encontrado: $file"
        exit 1
    fi
done

log_success "Todos os arquivos necessários encontrados"

# 7. Configurar permissões
log_info "7/8 Configurando permissões..."
chmod +x run.sh 2>/dev/null || true
chmod 644 *.json 2>/dev/null || true
chmod 644 static/* 2>/dev/null || true
log_success "Permissões configuradas"

# 8. Teste de funcionamento
log_info "8/8 Testando instalação..."

# Verificar se consegue importar as bibliotecas
python3 -c "
import flask
import telethon
import requests
import json
import os
print('✅ Todas as bibliotecas importadas com sucesso')
" 2>/dev/null

if [ $? -eq 0 ]; then
    log_success "Teste de importação passou"
else
    log_error "Falha no teste de importação"
    exit 1
fi

# Verificar se o arquivo principal está válido
python3 -m py_compile telegram_api_v4.py 2>/dev/null

if [ $? -eq 0 ]; then
    log_success "Arquivo principal válido"
else
    log_error "Erro de sintaxe no arquivo principal"
    exit 1
fi

echo ""
echo "🎉 INSTALAÇÃO CONCLUÍDA COM SUCESSO!"
echo "===================================="
echo ""
log_success "Telegram SaaS Pro v4 instalado e pronto para uso"
echo ""
echo "📋 PRÓXIMOS PASSOS:"
echo "1. Execute: ./run.sh"
echo "2. Acesse: http://localhost:5000"
echo "3. Conecte suas contas na aba 'Conectar Conta'"
echo "4. Configure webhooks na aba 'Gerenciar Contas'"
echo ""
echo "🔧 COMANDOS ÚTEIS:"
echo "• Iniciar: ./run.sh"
echo "• Parar: pkill -f telegram_api"
echo "• Logs: tail -f nohup.out"
echo "• Status: curl http://localhost:5000/api/status"
echo ""
log_info "Para suporte, consulte o README.md"
echo ""

