#!/bin/bash

# Telegram SaaS Pro v4 - Instalador Local
# Versão: 4.0 Final
# Data: $(date)

set -e  # Parar em caso de erro

echo "🚀 Telegram SaaS Pro v4 - Instalador Local"
echo "=========================================="
echo ""

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Função para log colorido
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

log_info "Iniciando instalação do Telegram SaaS Pro v4..."
echo ""

# 1. Verificar se está no diretório correto
if [ ! -f "telegram_api_v4.py" ]; then
    log_error "Arquivo telegram_api_v4.py não encontrado!"
    log_info "Execute este script no diretório do projeto"
    exit 1
fi

# 2. Verificar Python
log_info "1/6 Verificando Python..."
if ! command -v python3 &> /dev/null; then
    log_error "Python3 não encontrado"
    log_info "Instale Python3: apt install python3 python3-pip python3-venv"
    exit 1
fi

PYTHON_VERSION=$(python3 --version 2>/dev/null | cut -d' ' -f2 | cut -d'.' -f1,2)
log_success "Python $PYTHON_VERSION encontrado"

# 3. Verificar pip3
log_info "2/6 Verificando pip3..."
if ! command -v pip3 &> /dev/null; then
    log_warning "pip3 não encontrado, tentando instalar..."
    if command -v apt &> /dev/null; then
        apt update -qq > /dev/null 2>&1
        apt install -y python3-pip > /dev/null 2>&1
    else
        log_error "Não foi possível instalar pip3 automaticamente"
        exit 1
    fi
fi
log_success "pip3 verificado"

# 4. Criar ambiente virtual
log_info "3/6 Criando ambiente virtual..."
if [ ! -d "venv" ]; then
    python3 -m venv venv
    if [ $? -ne 0 ]; then
        log_error "Falha ao criar ambiente virtual"
        exit 1
    fi
    log_success "Ambiente virtual criado"
else
    log_warning "Ambiente virtual já existe"
fi

# 5. Ativar ambiente virtual e instalar dependências
log_info "4/6 Instalando dependências Python..."
source venv/bin/activate

# Atualizar pip
pip install --upgrade pip > /dev/null 2>&1 || {
    log_warning "Falha ao atualizar pip, continuando..."
}

# Instalar dependências uma por uma
log_info "   Instalando Flask..."
pip install Flask==2.3.3 > /dev/null 2>&1 || {
    log_warning "Falha ao instalar Flask 2.3.3, tentando versão mais recente..."
    pip install Flask > /dev/null 2>&1 || {
        log_error "Falha ao instalar Flask"
        exit 1
    }
}

log_info "   Instalando Telethon..."
pip install Telethon==1.29.3 > /dev/null 2>&1 || {
    log_warning "Falha ao instalar Telethon 1.29.3, tentando versão mais recente..."
    pip install Telethon > /dev/null 2>&1 || {
        log_error "Falha ao instalar Telethon"
        exit 1
    }
}

log_info "   Instalando requests..."
pip install requests==2.31.0 > /dev/null 2>&1 || {
    log_warning "Falha ao instalar requests 2.31.0, tentando versão mais recente..."
    pip install requests > /dev/null 2>&1 || {
        log_error "Falha ao instalar requests"
        exit 1
    }
}

log_success "Dependências Python instaladas"

# 6. Verificar arquivos necessários
log_info "5/6 Verificando arquivos do projeto..."

REQUIRED_FILES=(
    "telegram_api_v4.py"
    "static/index.html"
    "accounts.json"
    "webhooks.json"
    "config.json"
    "scheduled_messages.json"
)

for file in "${REQUIRED_FILES[@]}"; do
    if [ ! -f "$file" ]; then
        log_warning "Arquivo $file não encontrado, criando..."
        case $file in
            "accounts.json")
                echo '[]' > "$file"
                ;;
            "webhooks.json")
                echo '{}' > "$file"
                ;;
            "config.json")
                echo '{"webhook_url": ""}' > "$file"
                ;;
            "scheduled_messages.json")
                echo '[]' > "$file"
                ;;
            "static/index.html")
                mkdir -p static
                echo '<h1>Interface não encontrada</h1>' > "$file"
                ;;
        esac
        log_success "Arquivo $file criado"
    fi
done

log_success "Todos os arquivos verificados"

# 7. Teste final
log_info "6/6 Testando instalação..."

# Teste de importação
python3 -c "
try:
    import flask
    import telethon
    import requests
    import json
    import os
    print('✅ Todas as bibliotecas importadas com sucesso')
except ImportError as e:
    print(f'❌ Erro de importação: {e}')
    exit(1)
" 2>/dev/null

if [ $? -eq 0 ]; then
    log_success "Teste de importação passou"
else
    log_error "Falha no teste de importação"
    exit 1
fi

# Verificar sintaxe do arquivo principal
python3 -m py_compile telegram_api_v4.py 2>/dev/null

if [ $? -eq 0 ]; then
    log_success "Arquivo principal válido"
else
    log_error "Erro de sintaxe no arquivo principal"
    exit 1
fi

# Configurar permissões
chmod +x run.sh 2>/dev/null || true
chmod 644 *.json 2>/dev/null || true
chmod 644 static/* 2>/dev/null || true

echo ""
echo "🎉 INSTALAÇÃO CONCLUÍDA COM SUCESSO!"
echo "===================================="
echo ""
log_success "Telegram SaaS Pro v4 instalado e pronto para uso"
echo ""
echo "📋 PARA INICIAR:"
echo "./run.sh"
echo ""
echo "🌐 ACESSO:"
echo "http://localhost:5000"
echo ""
echo "🔧 COMANDOS ÚTEIS:"
echo "• Iniciar: ./run.sh"
echo "• Parar: Ctrl+C ou pkill -f telegram_api"
echo "• Logs: Ver no terminal"
echo "• Status: curl http://localhost:5000/api/status"
echo ""
echo "🌐 ACESSO EXTERNO (se necessário):"
echo "• Liberar firewall: ufw allow 5000"
echo "• Acesso externo: http://SEU_IP_VPS:5000"
echo ""
log_info "Sistema pronto para uso!"
echo ""

