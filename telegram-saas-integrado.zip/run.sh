#!/bin/bash

# Telegram SaaS Pro v4 - Script de Execução
# Versão: 4.0 Final
# Data: 10/08/2025

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Funções de log
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

log_header() {
    echo -e "${PURPLE}🚀 $1${NC}"
    echo "===================================="
}

# Header
clear
log_header "Telegram SaaS Pro v4"

# Verificar se está no diretório correto
if [ ! -f "telegram_api_v4.py" ]; then
    log_error "Arquivo telegram_api_v4.py não encontrado!"
    log_info "Execute este script no diretório do projeto"
    exit 1
fi

# Ativar ambiente virtual
log_info "🔧 Ativando ambiente virtual..."
if [ -d "venv" ]; then
    source venv/bin/activate
    log_success "Ambiente virtual ativado"
else
    log_warning "Ambiente virtual não encontrado, criando..."
    python3 -m venv venv
    source venv/bin/activate
    pip install -r requirements.txt
fi

# Verificar dependências
log_info "🔍 Verificando dependências..."
python3 -c "
import flask, telethon, requests
print('✅ Dependências verificadas')
" || {
    log_warning "Instalando dependências..."
    pip install -r requirements.txt
}

# Verificar porta
log_info "🌐 Verificando porta 5000..."
if lsof -Pi :5000 -sTCP:LISTEN -t >/dev/null 2>&1; then
    log_warning "Porta 5000 já está em uso"
    log_info "Parando processo anterior..."
    pkill -f telegram_api || true
    sleep 2
fi

# Informações do sistema
echo ""
log_info "📊 INFORMAÇÕES DO SISTEMA:"
echo "• Python: $(python3 --version 2>&1)"
echo "• Diretório: $(pwd)"
echo "• Data/Hora: $(date)"
echo "• Usuário: $(whoami)"
echo ""

# URLs de acesso
log_info "🌐 URLS DE ACESSO:"
echo "• Local: http://localhost:5000"

# Detectar IP externo
EXTERNAL_IP=$(curl -s ifconfig.me 2>/dev/null || curl -s ipinfo.io/ip 2>/dev/null || echo "IP_NAO_DETECTADO")
if [ "$EXTERNAL_IP" != "IP_NAO_DETECTADO" ]; then
    echo "• Rede local: http://$EXTERNAL_IP:5000"
fi

echo ""
log_info "🔧 COMANDOS ÚTEIS:"
echo "• Parar: Ctrl+C"
echo "• Status: curl http://localhost:5000/api/status"
echo "• Logs: Ver neste terminal"
echo ""

# Iniciar servidor
log_header "Iniciando servidor..."

# Verificar arquivos necessários
for file in accounts.json webhooks.json config.json scheduled_messages.json; do
    if [ ! -f "$file" ]; then
        log_warning "Arquivo $file não encontrado, criando..."
        case $file in
            "accounts.json") echo '[]' > "$file" ;;
            "webhooks.json") echo '{}' > "$file" ;;
            "config.json") echo '{"webhook_url": ""}' > "$file" ;;
            "scheduled_messages.json") echo '[]' > "$file" ;;
        esac
    fi
done

# Iniciar aplicação
python3 telegram_api_v4.py

