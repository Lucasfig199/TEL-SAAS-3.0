#!/bin/bash

# Telegram SaaS Pro v4 - Script de Execução
# Versão: 4.0 Final

echo "🚀 Iniciando Telegram SaaS Pro v4..."
echo "===================================="
echo ""

# Verificar se está no diretório correto
if [ ! -f "telegram_api_v4.py" ]; then
    echo "❌ Erro: Arquivo telegram_api_v4.py não encontrado!"
    echo "Execute este script no diretório do projeto"
    exit 1
fi

# Verificar se o ambiente virtual existe
if [ ! -d "venv" ]; then
    echo "❌ Erro: Ambiente virtual não encontrado!"
    echo "Execute primeiro: ./install.sh"
    exit 1
fi

# Ativar ambiente virtual
echo "🔧 Ativando ambiente virtual..."
source venv/bin/activate

# Verificar se as dependências estão instaladas
echo "🔍 Verificando dependências..."
python3 -c "
try:
    import flask
    import telethon
    import requests
    print('✅ Dependências verificadas')
except ImportError as e:
    print(f'❌ Dependência faltando: {e}')
    print('Execute: ./install.sh')
    exit(1)
"

if [ $? -ne 0 ]; then
    exit 1
fi

# Verificar porta 5000
echo "🌐 Verificando porta 5000..."
if lsof -Pi :5000 -sTCP:LISTEN -t >/dev/null 2>&1; then
    echo "⚠️  Porta 5000 já está em uso!"
    echo "Para parar processo anterior: pkill -f telegram_api"
    echo "Ou use uma porta diferente editando o arquivo telegram_api_v4.py"
    read -p "Deseja parar o processo anterior? (y/n): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        pkill -f telegram_api
        sleep 2
        echo "✅ Processo anterior finalizado"
    else
        echo "❌ Cancelando execução"
        exit 1
    fi
fi

# Mostrar informações do sistema
echo ""
echo "📊 INFORMAÇÕES DO SISTEMA:"
echo "• Python: $(python3 --version)"
echo "• Diretório: $(pwd)"
echo "• Data/Hora: $(date)"
echo "• Usuário: $(whoami)"
echo ""

# Mostrar URLs de acesso
echo "🌐 URLS DE ACESSO:"
echo "• Local: http://localhost:5000"
echo "• Rede local: http://$(hostname -I | awk '{print $1}'):5000"
echo ""

# Mostrar comandos úteis
echo "🔧 COMANDOS ÚTEIS:"
echo "• Parar: Ctrl+C"
echo "• Status: curl http://localhost:5000/api/status"
echo "• Logs: Ver neste terminal"
echo ""

echo "🚀 Iniciando servidor..."
echo "======================================"
echo ""

# Executar o servidor
python3 telegram_api_v4.py

# Se chegou aqui, o servidor foi finalizado
echo ""
echo "🛑 Servidor finalizado"
echo "Para reiniciar: ./run.sh"

