#!/bin/bash

# Telegram SaaS Pro v4 - Script de Execução
# Versão: 4.0 Clean

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Função para log colorido
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

echo "🚀 Telegram SaaS Pro v4 - Iniciando Sistema"
echo "==========================================="
echo ""

# Verificar se já está rodando
if pgrep -f "telegram_api_v4.py" > /dev/null; then
    log_warning "Sistema já está rodando!"
    echo ""
    echo "Para parar o sistema: pkill -f telegram_api"
    echo "Para ver logs: tail -f nohup.out"
    echo "Para verificar status: curl http://localhost:5000/api/status"
    exit 1
fi

# Verificar se o arquivo principal existe
if [ ! -f "telegram_api_v4.py" ]; then
    log_error "Arquivo telegram_api_v4.py não encontrado"
    log_info "Execute primeiro: ./install.sh"
    exit 1
fi

# Verificar se o ambiente virtual existe
if [ ! -d "venv" ]; then
    log_error "Ambiente virtual não encontrado"
    log_info "Execute primeiro: ./install.sh"
    exit 1
fi

# Ativar ambiente virtual
log_info "Ativando ambiente virtual..."
source venv/bin/activate

# Verificar dependências
log_info "Verificando dependências..."
python3 -c "
import flask
import telethon
import requests
" 2>/dev/null

if [ $? -ne 0 ]; then
    log_error "Dependências não encontradas"
    log_info "Execute: ./install.sh"
    exit 1
fi

log_success "Dependências verificadas"

# Verificar arquivos de configuração
log_info "Verificando arquivos de configuração..."

CONFIG_FILES=(
    "accounts.json"
    "webhooks.json"
    "config.json"
    "scheduled_messages.json"
)

for file in "${CONFIG_FILES[@]}"; do
    if [ ! -f "$file" ]; then
        log_warning "Arquivo $file não encontrado, criando..."
        case $file in
            "accounts.json")
                echo '[]' > "$file"
                ;;
            "webhooks.json")
                echo '{}' > "$file"
                ;;
            "config.json")
                echo '{"webhook_url": ""}' > "$file"
                ;;
            "scheduled_messages.json")
                echo '[]' > "$file"
                ;;
        esac
        log_success "Arquivo $file criado"
    fi
done

# Verificar porta 5000
log_info "Verificando porta 5000..."
if netstat -tuln 2>/dev/null | grep -q ":5000 "; then
    log_error "Porta 5000 já está em uso"
    log_info "Pare o serviço que está usando a porta 5000"
    exit 1
fi

log_success "Porta 5000 disponível"

# Limpar logs antigos se muito grandes
if [ -f "nohup.out" ] && [ $(stat -c%s "nohup.out") -gt 10485760 ]; then
    log_info "Limpando logs antigos (>10MB)..."
    > nohup.out
fi

# Iniciar sistema
log_info "Iniciando Telegram SaaS Pro v4..."
echo ""

nohup python3 telegram_api_v4.py > nohup.out 2>&1 &
PID=$!

# Aguardar inicialização
sleep 3

# Verificar se o processo está rodando
if ps -p $PID > /dev/null; then
    log_success "Sistema iniciado com sucesso! (PID: $PID)"
    echo ""
    
    # Aguardar servidor estar pronto
    log_info "Aguardando servidor estar pronto..."
    for i in {1..10}; do
        if curl -s http://localhost:5000/api/status > /dev/null 2>&1; then
            log_success "Servidor respondendo na porta 5000"
            break
        fi
        sleep 1
        echo -n "."
    done
    echo ""
    
    # Verificar se API está respondendo
    if curl -s http://localhost:5000/api/status > /dev/null 2>&1; then
        echo "🎉 SISTEMA INICIADO COM SUCESSO!"
        echo "==============================="
        echo ""
        echo "📊 ACESSO AO SISTEMA:"
        echo "• Interface Web: http://localhost:5000"
        echo "• API Status: http://localhost:5000/api/status"
        echo "• API Docs: http://localhost:5000 (aba API Docs)"
        echo ""
        echo "🔧 COMANDOS ÚTEIS:"
        echo "• Ver logs: tail -f nohup.out"
        echo "• Parar sistema: pkill -f telegram_api"
        echo "• Reiniciar: pkill -f telegram_api && ./run.sh"
        echo "• Status processo: ps aux | grep telegram_api"
        echo ""
        echo "📱 PRÓXIMOS PASSOS:"
        echo "1. Acesse http://localhost:5000"
        echo "2. Vá na aba 'Conectar Conta'"
        echo "3. Adicione suas credenciais do Telegram"
        echo "4. Configure webhooks na aba 'Gerenciar Contas'"
        echo ""
        log_info "Sistema rodando em background (PID: $PID)"
        
        # Mostrar primeiras linhas do log
        echo ""
        log_info "Primeiras linhas do log:"
        echo "------------------------"
        head -n 5 nohup.out 2>/dev/null || echo "Logs ainda não disponíveis"
        
    else
        log_error "Servidor não está respondendo"
        log_info "Verifique os logs: tail -f nohup.out"
        exit 1
    fi
else
    log_error "Falha ao iniciar o sistema"
    log_info "Verifique os logs: cat nohup.out"
    exit 1
fi

echo ""

