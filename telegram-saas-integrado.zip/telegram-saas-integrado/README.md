# 🚀 Telegram SaaS Pro v4

Sistema completo de gerenciamento de múltiplas contas Telegram com interface web moderna e API REST.

**Versão:** 4.0 (Versão única otimizada)

## ✨ Funcionalidades Principais

### 📊 Dashboard Moderno
- Gráficos interativos em tempo real
- Estatísticas de mensagens enviadas/recebidas
- Monitoramento de contas ativas
- Interface responsiva (desktop + mobile)

### 👥 Gerenciamento de Contas
- Conexão de múltiplas contas Telegram
- Autenticação via SMS
- Status de conexão em tempo real
- Webhooks individuais por conta

### 📤 Envio de Mensagens
- Mensagens de texto com formatação
- Envio de fotos, vídeos e áudios
- Seleção de conta remetente
- Suporte a chat ID e @username

### 🎯 Gestão de Leads
- Adicionar leads em grupos específicos
- Importação em massa de leads
- Criação automática de grupos
- Mensagens de boas-vindas personalizadas

### ⏰ Agendamento
- Mensagens programadas
- Repetição automática (diário/semanal/mensal)
- Fuso horário configurável

### 🔗 Webhooks Avançados
- Webhook individual por conta
- Notificações em tempo real
- Dados estruturados em JSON
- Retry automático em falhas

## 🛠️ Instalação

### Pré-requisitos
- Python 3.7+
- pip3
- Conta Telegram com API credentials

### Instalação Rápida

```bash
# 1. Extrair arquivos
unzip telegram-saas-pro-v4.zip
cd telegram-saas-pro-v4

# 2. Executar instalação
./install.sh

# 3. Iniciar servidor
./run.sh
```

### Instalação Manual

```bash
# Instalar dependências
pip3 install -r requirements.txt

# Criar arquivos de configuração
echo '{"webhook_url": ""}' > config.json
echo '[]' > accounts.json
echo '{}' > webhooks.json
echo '[]' > scheduled_messages.json

# Iniciar servidor
python3 telegram_api_v4.py
```

## 🌐 Acesso

Após iniciar o servidor:
- **Dashboard**: http://localhost:5000
- **API Base**: http://localhost:5000/api/

## 📚 API Endpoints

### 🔐 Autenticação
- `POST /api/connect-account` - Conectar nova conta
- `POST /api/verify-code` - Verificar código SMS
- `DELETE /api/remove-account` - Remover conta

### 📤 Envio de Mensagens
- `POST /api/send-message` - Enviar mensagem de texto
- `POST /api/send-photo` - Enviar foto
- `POST /api/send-video` - Enviar vídeo
- `POST /api/send-audio` - Enviar áudio

### 🎯 Gestão de Leads
- `POST /api/add-lead-to-group` - Adicionar lead ao grupo
- `POST /api/bulk-add-leads` - Adicionar múltiplos leads
- `POST /api/create-group-for-leads` - Criar grupo para leads
- `GET /api/get-group-info` - Informações do grupo

### ⏰ Agendamento
- `POST /api/schedule-message` - Agendar mensagem

### 🔗 Webhooks
- `POST /api/set-webhook` - Configurar webhook
- `GET /api/get-config` - Obter configurações

### 📊 Status
- `GET /api/status` - Status do sistema
- `GET /api/accounts` - Listar contas

## 🎯 Exemplos de Uso

### Conectar Conta
```bash
curl -X POST http://localhost:5000/api/connect-account \
  -H "Content-Type: application/json" \
  -d '{
    "phone": "+5511999999999",
    "api_id": 12345678,
    "api_hash": "abcdef1234567890abcdef1234567890"
  }'
```

### Enviar Mensagem
```bash
curl -X POST http://localhost:5000/api/send-message \
  -H "Content-Type: application/json" \
  -d '{
    "chat_id": "1791791982",
    "message": "Olá! Esta é uma mensagem de teste.",
    "sender_phone": "+5511999999999"
  }'
```

### Adicionar Lead ao Grupo
```bash
curl -X POST http://localhost:5000/api/add-lead-to-group \
  -H "Content-Type: application/json" \
  -d '{
    "lead_phone": "+5511888888888",
    "group_id": "-1001234567890",
    "welcome_message": "Bem-vindo ao grupo!",
    "sender_phone": "+5511999999999"
  }'
```

### Configurar Webhook Individual
```bash
curl -X POST http://localhost:5000/api/set-webhook \
  -H "Content-Type: application/json" \
  -d '{
    "webhook_url": "https://meusite.com/webhook/conta1",
    "sender_phone": "+5511999999999"
  }'
```

## 🔧 Configuração

### Obter API Credentials
1. Acesse https://my.telegram.org
2. Faça login com sua conta Telegram
3. Vá em "API Development Tools"
4. Crie uma nova aplicação
5. Anote o `api_id` e `api_hash`

### Configurar Webhooks
- **Global**: Configure na interface web (aba Dashboard)
- **Individual**: Configure na aba "Gerenciar Contas"
- **API**: Use o endpoint `/api/set-webhook`

## 📁 Estrutura de Arquivos

```
telegram-saas-pro-v4/
├── telegram_api_v4.py      # Backend principal (ÚNICO)
├── static/
│   └── index.html          # Interface web
├── requirements.txt        # Dependências Python
├── install.sh             # Script de instalação
├── run.sh                 # Script de execução
├── config.json            # Configurações globais
├── accounts.json          # Dados das contas
├── webhooks.json          # Webhooks individuais
├── scheduled_messages.json # Mensagens agendadas
└── README.md              # Esta documentação
```

## 🔒 Segurança

- Sessões Telegram criptografadas
- Webhooks com retry automático
- Logs detalhados de operações
- Validação de entrada em todos endpoints
- Isolamento de contas por webhook

## 🐛 Troubleshooting

### Erro de Conexão
```bash
# Verificar se as dependências estão instaladas
python3 -c "import flask, telethon, requests"

# Reinstalar dependências
pip3 install -r requirements.txt --force-reinstall
```

### Erro de Autenticação
- Verifique se `api_id` e `api_hash` estão corretos
- Confirme se o código SMS foi digitado corretamente
- Aguarde alguns minutos antes de tentar novamente

### Webhook não Funciona
- Verifique se a URL está acessível
- Confirme se o endpoint aceita POST com JSON
- Verifique os logs do servidor

## 📈 Performance

- **Múltiplas contas**: Suporte ilimitado
- **Mensagens/minuto**: ~60 por conta (limite Telegram)
- **Webhooks**: Processamento assíncrono
- **Agendamento**: Precisão de 1 minuto

## 🔄 Atualizações

Para atualizar para uma nova versão:
1. Faça backup dos arquivos `.json`
2. Substitua os arquivos do sistema
3. Execute `./install.sh` novamente
4. Reinicie com `./run.sh`

## 📞 Suporte

- **Logs**: Verifique o console para erros detalhados
- **API**: Teste endpoints via curl ou Postman
- **Interface**: Use F12 para debug do frontend

## 📄 Licença

Este software é fornecido "como está" para uso pessoal e comercial.

---

**Telegram SaaS Pro v4** - Sistema profissional de gerenciamento Telegram

