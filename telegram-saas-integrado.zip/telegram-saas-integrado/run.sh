#!/bin/bash

echo "🚀 Iniciando Telegram SaaS Pro v4..."
echo ""
echo "🌐 Servidor será iniciado em: http://localhost:5000"
echo "📊 Dashboard: http://localhost:5000"
echo ""
echo "⚡ Para parar o servidor: Ctrl+C"
echo ""

# Verificar se as dependências estão instaladas
if ! python3 -c "import flask, telethon, requests" 2>/dev/null; then
    echo "❌ Dependências não encontradas. Execute primeiro:"
    echo "   ./install.sh"
    exit 1
fi

# Iniciar o servidor V4
python3 telegram_api_v4.py

