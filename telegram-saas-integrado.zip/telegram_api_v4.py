from flask import Flask, request, jsonify, send_from_directory
from telethon import TelegramClient, events
from telethon.tl.functions.channels import InviteToChannelRequest, CreateChannelRequest
from telethon.tl.functions.messages import AddChatUserRequest, CreateChatRequest
from telethon.tl.types import InputPeerUser, InputPeerChat, InputPeerChannel
import asyncio
import json
import os
import logging
from datetime import datetime, timedelta
import threading
import requests
import time

# Configuracao de logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

app = Flask(__name__)

# Caminhos para os arquivos
ACCOUNTS_FILE = 'accounts.json'
CONFIG_FILE = 'config.json'
WEBHOOKS_FILE = 'webhooks.json'
SCHEDULED_MESSAGES_FILE = 'scheduled_messages.json'

# Dicionario para armazenar clientes Telethon ativos
telegram_clients = {}

# Dicionario para armazenar o estado de verificacao
pending_verifications = {}

# Variaveis de estatisticas
stats = {'messages_sent': 0, 'messages_received': 0, 'webhook_calls': 0}

# Loop de eventos global para Telethon
telethon_loop = None
telethon_thread = None

# --- Funcoes de Gerenciamento de Configuracao ---

def load_config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, 'r') as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                logger.error(f"Erro ao decodificar {CONFIG_FILE}. Retornando configuracao padrao.")
                return {'webhook_url': ''}
    else:
        return {'webhook_url': ''}

def save_config(config):
    with open(CONFIG_FILE, 'w') as f:
        json.dump(config, f, indent=2)

def load_accounts():
    if os.path.exists(ACCOUNTS_FILE):
        with open(ACCOUNTS_FILE, 'r') as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                logger.error(f"Erro ao decodificar {ACCOUNTS_FILE}. Retornando lista vazia.")
                return []
    else:
        return []

def save_accounts(accounts):
    with open(ACCOUNTS_FILE, 'w') as f:
        json.dump(accounts, f, indent=2)

def load_webhooks():
    if os.path.exists(WEBHOOKS_FILE):
        with open(WEBHOOKS_FILE, 'r') as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                logger.error(f"Erro ao decodificar {WEBHOOKS_FILE}. Retornando dicionario vazio.")
                return {}
    else:
        return {}

def save_webhooks(webhooks):
    with open(WEBHOOKS_FILE, 'w') as f:
        json.dump(webhooks, f, indent=2)

def load_scheduled_messages():
    if os.path.exists(SCHEDULED_MESSAGES_FILE):
        with open(SCHEDULED_MESSAGES_FILE, 'r') as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                logger.error(f"Erro ao decodificar {SCHEDULED_MESSAGES_FILE}. Retornando lista vazia.")
                return []
    else:
        return []

def save_scheduled_messages(messages):
    with open(SCHEDULED_MESSAGES_FILE, 'w') as f:
        json.dump(messages, f, indent=2)

# --- Funcoes de Telethon ---

def get_active_client():
    """Retorna o primeiro cliente ativo disponivel"""
    for phone, client in telegram_clients.items():
        if client and client.is_connected():
            return client
    return None

def get_client_by_phone(phone):
    """Retorna o cliente especifico pelo numero de telefone"""
    return telegram_clients.get(phone)

async def create_telegram_client(phone, api_id, api_hash):
    """Cria um novo cliente Telegram"""
    try:
        session_name = f"session_{phone.replace('+', '').replace('-', '').replace(' ', '')}"
        client = TelegramClient(session_name, api_id, api_hash)
        
        await client.connect()
        
        if not await client.is_user_authorized():
            await client.send_code_request(phone)
            return client, False  # Nao autorizado, precisa de codigo
        else:
            telegram_clients[phone] = client
            return client, True  # Ja autorizado
            
    except Exception as e:
        logger.error(f"Erro ao criar cliente Telegram para {phone}: {e}")
        return None, False

async def verify_telegram_code(phone, code):
    """Verifica o codigo de autenticacao"""
    try:
        if phone in pending_verifications:
            client = pending_verifications[phone]
            await client.sign_in(phone, code)
            
            # Mover para clientes ativos
            telegram_clients[phone] = client
            del pending_verifications[phone]
            
            return True
    except Exception as e:
        logger.error(f"Erro ao verificar codigo para {phone}: {e}")
        return False

# --- Funcoes de Webhook ---

def send_webhook(webhook_url, data):
    """Envia dados para webhook"""
    try:
        if webhook_url:
            response = requests.post(webhook_url, json=data, timeout=10)
            stats['webhook_calls'] += 1
            logger.info(f"Webhook enviado para {webhook_url}: {response.status_code}")
    except Exception as e:
        logger.error(f"Erro ao enviar webhook: {e}")

# --- Rotas da API ---

@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

@app.route('/static/<path:filename>')
def static_files(filename):
    return send_from_directory('static', filename)

@app.route('/api/status', methods=['GET'])
def get_status():
    accounts = load_accounts()
    active_accounts = []
    
    for account in accounts:
        phone = account.get('phone')
        if phone in telegram_clients:
            client = telegram_clients[phone]
            account['connected'] = client.is_connected() if client else False
        else:
            account['connected'] = False
        active_accounts.append(account)
    
    return jsonify({
        'status': 'online',
        'accounts': active_accounts,
        'stats': stats,
        'total_accounts': len(accounts),
        'active_accounts': len([acc for acc in active_accounts if acc.get('connected', False)])
    })

@app.route('/api/accounts', methods=['GET'])
def get_accounts():
    accounts = load_accounts()
    
    # Atualizar status de conexao
    for account in accounts:
        phone = account.get('phone')
        if phone in telegram_clients:
            client = telegram_clients[phone]
            account['connected'] = client.is_connected() if client else False
        else:
            account['connected'] = False
    
    return jsonify({'accounts': accounts})

@app.route('/api/connect-account', methods=['POST'])
def connect_account():
    try:
        data = request.get_json()
        phone = data.get('phone')
        api_id = int(data.get('api_id'))
        api_hash = data.get('api_hash')
        
        if not phone or not api_id or not api_hash:
            return jsonify({'error': 'Todos os campos sao obrigatorios'}), 400
        
        # Executar em thread separada para nao bloquear
        def connect_async():
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                client, authorized = loop.run_until_complete(
                    create_telegram_client(phone, api_id, api_hash)
                )
                
                if client:
                    if not authorized:
                        pending_verifications[phone] = client
                        return {'success': True, 'needs_verification': True, 'message': 'Codigo enviado via SMS'}
                    else:
                        # Salvar conta
                        accounts = load_accounts()
                        account_data = {
                            'phone': phone,
                            'api_id': api_id,
                            'api_hash': api_hash,
                            'connected': True,
                            'added_at': datetime.now().isoformat()
                        }
                        
                        # Verificar se ja existe
                        existing_index = None
                        for i, acc in enumerate(accounts):
                            if acc.get('phone') == phone:
                                existing_index = i
                                break
                        
                        if existing_index is not None:
                            accounts[existing_index] = account_data
                        else:
                            accounts.append(account_data)
                        
                        save_accounts(accounts)
                        return {'success': True, 'needs_verification': False, 'message': 'Conta conectada com sucesso'}
                else:
                    return {'error': 'Falha ao conectar conta'}
            except Exception as e:
                logger.error(f"Erro na conexao: {e}")
                return {'error': str(e)}
            finally:
                loop.close()
        
        result = connect_async()
        
        if 'error' in result:
            return jsonify(result), 500
        else:
            return jsonify(result)
            
    except Exception as e:
        logger.error(f"Erro ao conectar conta: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/verify-code', methods=['POST'])
def verify_code():
    try:
        data = request.get_json()
        phone = data.get('phone')
        code = data.get('code')
        
        if not phone or not code:
            return jsonify({'error': 'Telefone e codigo sao obrigatorios'}), 400
        
        def verify_async():
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                success = loop.run_until_complete(verify_telegram_code(phone, code))
                
                if success:
                    # Salvar conta
                    accounts = load_accounts()
                    
                    # Buscar dados da conta pendente
                    account_data = None
                    for acc in accounts:
                        if acc.get('phone') == phone:
                            account_data = acc
                            break
                    
                    if not account_data:
                        # Criar nova entrada se nao existir
                        account_data = {
                            'phone': phone,
                            'connected': True,
                            'added_at': datetime.now().isoformat()
                        }
                        accounts.append(account_data)
                    else:
                        account_data['connected'] = True
                    
                    save_accounts(accounts)
                    return {'success': True, 'message': 'Conta verificada e conectada com sucesso'}
                else:
                    return {'error': 'Codigo invalido'}
            except Exception as e:
                logger.error(f"Erro na verificacao: {e}")
                return {'error': str(e)}
            finally:
                loop.close()
        
        result = verify_async()
        
        if 'error' in result:
            return jsonify(result), 400
        else:
            return jsonify(result)
            
    except Exception as e:
        logger.error(f"Erro ao verificar codigo: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/remove-account', methods=['DELETE'])
def remove_account():
    try:
        data = request.get_json()
        phone = data.get('phone')
        
        if not phone:
            return jsonify({'error': 'Numero de telefone e obrigatorio'}), 400
        
        # Remover cliente ativo
        if phone in telegram_clients:
            client = telegram_clients[phone]
            if client:
                try:
                    asyncio.run(client.disconnect())
                except:
                    pass
            del telegram_clients[phone]
        
        # Remover da lista de contas
        accounts = load_accounts()
        accounts = [acc for acc in accounts if acc.get('phone') != phone]
        save_accounts(accounts)
        
        # Remover webhook
        webhooks = load_webhooks()
        if phone in webhooks:
            del webhooks[phone]
            save_webhooks(webhooks)
        
        return jsonify({'success': True, 'message': 'Conta removida com sucesso'})
        
    except Exception as e:
        logger.error(f"Erro ao remover conta: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/set-webhook', methods=['POST'])
def set_webhook():
    try:
        data = request.get_json()
        webhook_url = data.get('webhook_url')
        sender_phone = data.get('sender_phone')
        
        if not webhook_url:
            return jsonify({'error': 'URL do webhook e obrigatoria'}), 400
        
        if sender_phone:
            # Webhook individual para conta especifica
            webhooks = load_webhooks()
            webhooks[sender_phone] = webhook_url
            save_webhooks(webhooks)
            
            return jsonify({
                'success': True, 
                'message': f'Webhook configurado para conta {sender_phone}'
            })
        else:
            # Webhook global
            config = load_config()
            config['webhook_url'] = webhook_url
            save_config(config)
            
            return jsonify({
                'success': True, 
                'message': 'Webhook global configurado com sucesso'
            })
            
    except Exception as e:
        logger.error(f"Erro ao configurar webhook: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/get-config', methods=['GET'])
def get_config():
    config = load_config()
    accounts = load_accounts()
    
    return jsonify({
        'webhook_url': config.get('webhook_url', ''),
        'accounts_count': len(accounts),
        'system_status': 'online'
    })

@app.route('/api/send-message', methods=['POST'])
def send_message():
    try:
        data = request.get_json()
        chat_id = data.get('chat_id')
        message = data.get('message')
        sender_phone = data.get('sender_phone')
        
        if not chat_id or not message:
            return jsonify({'error': 'chat_id e message sao obrigatorios'}), 400
        
        def send_async():
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                # Escolher cliente
                if sender_phone:
                    client = get_client_by_phone(sender_phone)
                    if not client:
                        return {'error': f'Conta {sender_phone} nao encontrada ou desconectada'}
                else:
                    client = get_active_client()
                    if not client:
                        return {'error': 'Nenhuma conta ativa encontrada'}
                
                # Enviar mensagem
                result = loop.run_until_complete(client.send_message(chat_id, message))
                
                stats['messages_sent'] += 1
                
                return {
                    'success': True,
                    'message': 'Mensagem enviada com sucesso',
                    'message_id': result.id,
                    'chat_id': chat_id,
                    'sender_phone': sender_phone or 'conta_ativa'
                }
                
            except Exception as e:
                logger.error(f"Erro ao enviar mensagem: {e}")
                return {'error': str(e)}
            finally:
                loop.close()
        
        result = send_async()
        
        if 'error' in result:
            return jsonify(result), 500
        else:
            return jsonify(result)
            
    except Exception as e:
        logger.error(f"Erro ao processar envio de mensagem: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/send-photo', methods=['POST'])
def send_photo():
    try:
        data = request.get_json()
        chat_id = data.get('chat_id')
        photo_url = data.get('photo_url')
        caption = data.get('caption', '')
        sender_phone = data.get('sender_phone')
        
        if not chat_id or not photo_url:
            return jsonify({'error': 'chat_id e photo_url sao obrigatorios'}), 400
        
        def send_async():
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                # Escolher cliente
                if sender_phone:
                    client = get_client_by_phone(sender_phone)
                    if not client:
                        return {'error': f'Conta {sender_phone} nao encontrada ou desconectada'}
                else:
                    client = get_active_client()
                    if not client:
                        return {'error': 'Nenhuma conta ativa encontrada'}
                
                # Enviar foto
                result = loop.run_until_complete(
                    client.send_file(chat_id, photo_url, caption=caption)
                )
                
                stats['messages_sent'] += 1
                
                return {
                    'success': True,
                    'message': 'Foto enviada com sucesso',
                    'message_id': result.id,
                    'chat_id': chat_id,
                    'sender_phone': sender_phone or 'conta_ativa'
                }
                
            except Exception as e:
                logger.error(f"Erro ao enviar foto: {e}")
                return {'error': str(e)}
            finally:
                loop.close()
        
        result = send_async()
        
        if 'error' in result:
            return jsonify(result), 500
        else:
            return jsonify(result)
            
    except Exception as e:
        logger.error(f"Erro ao processar envio de foto: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/send-video', methods=['POST'])
def send_video():
    try:
        data = request.get_json()
        chat_id = data.get('chat_id')
        video_url = data.get('video_url')
        caption = data.get('caption', '')
        sender_phone = data.get('sender_phone')
        
        if not chat_id or not video_url:
            return jsonify({'error': 'chat_id e video_url sao obrigatorios'}), 400
        
        def send_async():
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                # Escolher cliente
                if sender_phone:
                    client = get_client_by_phone(sender_phone)
                    if not client:
                        return {'error': f'Conta {sender_phone} nao encontrada ou desconectada'}
                else:
                    client = get_active_client()
                    if not client:
                        return {'error': 'Nenhuma conta ativa encontrada'}
                
                # Enviar video
                result = loop.run_until_complete(
                    client.send_file(chat_id, video_url, caption=caption)
                )
                
                stats['messages_sent'] += 1
                
                return {
                    'success': True,
                    'message': 'Video enviado com sucesso',
                    'message_id': result.id,
                    'chat_id': chat_id,
                    'sender_phone': sender_phone or 'conta_ativa'
                }
                
            except Exception as e:
                logger.error(f"Erro ao enviar video: {e}")
                return {'error': str(e)}
            finally:
                loop.close()
        
        result = send_async()
        
        if 'error' in result:
            return jsonify(result), 500
        else:
            return jsonify(result)
            
    except Exception as e:
        logger.error(f"Erro ao processar envio de video: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/send-audio', methods=['POST'])
def send_audio():
    try:
        data = request.get_json()
        chat_id = data.get('chat_id')
        audio_url = data.get('audio_url')
        caption = data.get('caption', '')
        sender_phone = data.get('sender_phone')
        
        if not chat_id or not audio_url:
            return jsonify({'error': 'chat_id e audio_url sao obrigatorios'}), 400
        
        def send_async():
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                # Escolher cliente
                if sender_phone:
                    client = get_client_by_phone(sender_phone)
                    if not client:
                        return {'error': f'Conta {sender_phone} nao encontrada ou desconectada'}
                else:
                    client = get_active_client()
                    if not client:
                        return {'error': 'Nenhuma conta ativa encontrada'}
                
                # Enviar audio
                result = loop.run_until_complete(
                    client.send_file(chat_id, audio_url, caption=caption)
                )
                
                stats['messages_sent'] += 1
                
                return {
                    'success': True,
                    'message': 'Audio enviado com sucesso',
                    'message_id': result.id,
                    'chat_id': chat_id,
                    'sender_phone': sender_phone or 'conta_ativa'
                }
                
            except Exception as e:
                logger.error(f"Erro ao enviar audio: {e}")
                return {'error': str(e)}
            finally:
                loop.close()
        
        result = send_async()
        
        if 'error' in result:
            return jsonify(result), 500
        else:
            return jsonify(result)
            
    except Exception as e:
        logger.error(f"Erro ao processar envio de audio: {e}")
        return jsonify({'error': str(e)}), 500

# --- Endpoints de Leads e Grupos ---

@app.route('/api/add-lead-to-group', methods=['POST'])
def add_lead_to_group():
    try:
        data = request.get_json()
        lead_phone = data.get('lead_phone')
        group_id = data.get('group_id')
        welcome_message = data.get('welcome_message', '')
        sender_phone = data.get('sender_phone')
        
        if not lead_phone or not group_id:
            return jsonify({'error': 'lead_phone e group_id sao obrigatorios'}), 400
        
        # Simular adicao de lead (implementar logica real aqui)
        return jsonify({
            'success': True,
            'message': f'Lead {lead_phone} adicionado ao grupo {group_id}',
            'lead_phone': lead_phone,
            'group_id': group_id,
            'sender_phone': sender_phone or 'conta_ativa'
        })
        
    except Exception as e:
        logger.error(f"Erro ao adicionar lead ao grupo: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/bulk-add-leads', methods=['POST'])
def bulk_add_leads():
    try:
        data = request.get_json()
        leads = data.get('leads', [])
        target_groups = data.get('target_groups', [])
        distribution_method = data.get('distribution_method', 'round_robin')
        delay_between_adds = data.get('delay_between_adds', 2)
        
        if not leads or not target_groups:
            return jsonify({'error': 'leads e target_groups sao obrigatorios'}), 400
        
        # Simular adicao em massa (implementar logica real aqui)
        return jsonify({
            'success': True,
            'message': f'{len(leads)} leads processados para {len(target_groups)} grupos',
            'leads_count': len(leads),
            'groups_count': len(target_groups),
            'distribution_method': distribution_method
        })
        
    except Exception as e:
        logger.error(f"Erro ao adicionar leads em massa: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/create-group-for-leads', methods=['POST'])
def create_group_for_leads():
    try:
        data = request.get_json()
        group_title = data.get('group_title')
        group_description = data.get('group_description', '')
        leads_list = data.get('leads_list', [])
        sender_phone = data.get('sender_phone')
        
        if not group_title:
            return jsonify({'error': 'group_title e obrigatorio'}), 400
        
        # Simular criacao de grupo (implementar logica real aqui)
        fake_group_id = f"-100{int(time.time())}"
        
        return jsonify({
            'success': True,
            'message': f'Grupo "{group_title}" criado com sucesso',
            'group_id': fake_group_id,
            'group_title': group_title,
            'leads_added': len(leads_list),
            'sender_phone': sender_phone or 'conta_ativa'
        })
        
    except Exception as e:
        logger.error(f"Erro ao criar grupo para leads: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/get-group-info', methods=['GET'])
def get_group_info():
    try:
        group_id = request.args.get('group_id')
        sender_phone = request.args.get('sender_phone')
        
        if not group_id:
            return jsonify({'error': 'group_id e obrigatorio'}), 400
        
        # Simular informacoes do grupo (implementar logica real aqui)
        return jsonify({
            'success': True,
            'group_id': group_id,
            'title': 'Grupo de Exemplo',
            'description': 'Descricao do grupo',
            'members_count': 42,
            'created_at': datetime.now().isoformat(),
            'sender_phone': sender_phone or 'conta_ativa'
        })
        
    except Exception as e:
        logger.error(f"Erro ao obter informacoes do grupo: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/schedule-message', methods=['POST'])
def schedule_message():
    try:
        data = request.get_json()
        chat_id = data.get('chat_id')
        message = data.get('message')
        schedule_time = data.get('schedule_time')
        repeat = data.get('repeat', 'none')
        
        if not chat_id or not message or not schedule_time:
            return jsonify({'error': 'chat_id, message e schedule_time sao obrigatorios'}), 400
        
        # Salvar mensagem agendada
        scheduled_messages = load_scheduled_messages()
        
        scheduled_message = {
            'id': len(scheduled_messages) + 1,
            'chat_id': chat_id,
            'message': message,
            'schedule_time': schedule_time,
            'repeat': repeat,
            'created_at': datetime.now().isoformat(),
            'status': 'pending'
        }
        
        scheduled_messages.append(scheduled_message)
        save_scheduled_messages(scheduled_messages)
        
        return jsonify({
            'success': True,
            'message': 'Mensagem agendada com sucesso',
            'scheduled_message': scheduled_message
        })
        
    except Exception as e:
        logger.error(f"Erro ao agendar mensagem: {e}")
        return jsonify({'error': str(e)}), 500

# --- Inicializacao ---

def initialize_files():
    """Inicializa arquivos de configuracao se nao existirem"""
    
    # Criar accounts.json
    if not os.path.exists(ACCOUNTS_FILE):
        with open(ACCOUNTS_FILE, 'w') as f:
            json.dump([], f)
    
    # Criar config.json
    if not os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, 'w') as f:
            json.dump({'webhook_url': ''}, f)
    
    # Criar webhooks.json
    if not os.path.exists(WEBHOOKS_FILE):
        with open(WEBHOOKS_FILE, 'w') as f:
            json.dump({}, f)
    
    # Criar scheduled_messages.json
    if not os.path.exists(SCHEDULED_MESSAGES_FILE):
        with open(SCHEDULED_MESSAGES_FILE, 'w') as f:
            json.dump([], f)

if __name__ == '__main__':
    logger.info("Iniciando Telegram SaaS Pro v4...")
    
    # Inicializar arquivos
    initialize_files()
    
    logger.info("Sistema iniciado com sucesso!")
    logger.info("Acesse: http://localhost:5000")
    
    # Iniciar servidor Flask
    app.run(host='0.0.0.0', port=5000, debug=False)

