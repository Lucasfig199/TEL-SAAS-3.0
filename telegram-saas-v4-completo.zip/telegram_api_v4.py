# -*- coding: utf-8 -*-
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from telethon import TelegramClient, events
from telethon.tl.functions.channels import InviteToChannelRequest, CreateChannelRequest
from telethon.tl.functions.messages import AddChatUserRequest
from telethon.tl.types import InputPeerUser, InputPeerChannel
import asyncio
import json
import os
import logging
from datetime import datetime, timedelta
import threading
import requests
import schedule
import time
from collections import deque
import uuid

# Configuracao de logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)  # Permitir CORS para todas as rotas

# Caminhos para os arquivos
ACCOUNTS_FILE = 'accounts.json'
CONFIG_FILE = 'config.json'
SCHEDULED_MESSAGES_FILE = 'scheduled_messages.json'
LOGS_FILE = 'system_logs.json'

# Dicionario para armazenar clientes Telethon ativos
telegram_clients = {}

# Dicionario para armazenar o estado de verificacao
pending_verifications = {}

# Variaveis de estatisticas
stats = {
    'messages_sent': 0, 
    'messages_received': 0, 
    'webhook_calls': 0,
    'groups_created': 0,
    'leads_added': 0,
    'scheduled_messages': 0
}

# Fila de logs do sistema (máximo 1000 entradas)
system_logs = deque(maxlen=1000)

# Loop de eventos global para Telethon
telethon_loop = None
telethon_thread = None

# Thread para agendamento
scheduler_thread = None

# --- Funcoes de Logging ---

def add_system_log(level, message, account_phone=None):
    """Adiciona um log ao sistema"""
    log_entry = {
        'timestamp': datetime.now().isoformat(),
        'level': level,
        'message': message,
        'account_phone': account_phone
    }
    system_logs.append(log_entry)
    
    # Salvar logs em arquivo
    try:
        logs_list = list(system_logs)
        with open(LOGS_FILE, 'w') as f:
            json.dump(logs_list, f, indent=2)
    except Exception as e:
        logger.error(f"Erro ao salvar logs: {e}")

def load_system_logs():
    """Carrega logs do arquivo"""
    if os.path.exists(LOGS_FILE):
        try:
            with open(LOGS_FILE, 'r') as f:
                logs_data = json.load(f)
                system_logs.extend(logs_data[-1000:])  # Carregar apenas os últimos 1000
        except Exception as e:
            logger.error(f"Erro ao carregar logs: {e}")

# --- Funcoes de Gerenciamento de Configuracao ---

def load_config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, 'r') as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                logger.error(f"Erro ao decodificar {CONFIG_FILE}. Retornando configuracao padrao.")
                return {'webhook_url': '', 'accounts_webhooks': {}}
    return {'webhook_url': '', 'accounts_webhooks': {}}

def save_config(config):
    with open(CONFIG_FILE, 'w') as f:
        json.dump(config, f, indent=2)

# --- Funcoes de Gerenciamento de Contas ---

def load_accounts():
    if os.path.exists(ACCOUNTS_FILE):
        with open(ACCOUNTS_FILE, 'r') as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                logger.error(f"Erro ao decodificar {ACCOUNTS_FILE}. Retornando lista vazia.")
                return []
    return []

def save_accounts(accounts):
    with open(ACCOUNTS_FILE, 'w') as f:
        json.dump(accounts, f, indent=2)

# --- Funcoes de Mensagens Agendadas ---

def load_scheduled_messages():
    if os.path.exists(SCHEDULED_MESSAGES_FILE):
        with open(SCHEDULED_MESSAGES_FILE, 'r') as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                logger.error(f"Erro ao decodificar {SCHEDULED_MESSAGES_FILE}. Retornando lista vazia.")
                return []
    return []

def save_scheduled_messages(messages):
    with open(SCHEDULED_MESSAGES_FILE, 'w') as f:
        json.dump(messages, f, indent=2)

def run_in_telethon_loop(coro):
    """Executa uma corrotina no loop do Telethon"""
    if telethon_loop and telethon_loop.is_running():
        future = asyncio.run_coroutine_threadsafe(coro, telethon_loop)
        return future.result(timeout=30)
    else:
        raise RuntimeError("Loop do Telethon nao esta disponivel")

async def setup_client_handlers(client, account_data):
    """Configura os handlers de eventos para um cliente"""
    phone = account_data['phone']
    
    @client.on(events.NewMessage(incoming=True))
    async def handler(event):
        try:
            # Verificacao de seguranca para sender e chat
            try:
                sender = await event.get_sender()
                chat = await event.get_chat()
            except Exception as e:
                logger.error(f"Erro ao obter sender/chat para {phone}: {e}")
                return
            
            # Verificar se sender e chat nao sao None
            if not sender or not chat or not event.message:
                return
            
            message_text = event.message.message or ''
            
            # Detectar tipo de midia
            media_type = 'text'
            if event.message.media:
                if hasattr(event.message.media, 'photo'):
                    media_type = 'photo'
                elif hasattr(event.message.media, 'document'):
                    media_type = 'document'
                elif hasattr(event.message.media, 'voice'):
                    media_type = 'voice'
                else:
                    media_type = 'other_media'

            # Enviar para webhook individual da conta ou webhook global
            config = load_config()
            account_webhook = config.get('accounts_webhooks', {}).get(phone)
            webhook_url = account_webhook or config.get('webhook_url')
            
            if webhook_url:
                webhook_data = {
                    'event_type': 'message_received',
                    'timestamp': datetime.now().isoformat(),
                    'account_phone': phone,
                    'message': {
                        'id': event.message.id,
                        'text': message_text,
                        'date': event.message.date.isoformat() if event.message.date else datetime.now().isoformat(),
                        'media_type': media_type,
                        'reply_to_message_id': getattr(event.message, 'reply_to_msg_id', None),
                        'has_media': event.message.media is not None,
                    },
                    'sender': {
                        'id': getattr(sender, 'id', None),
                        'username': getattr(sender, 'username', None),
                        'first_name': getattr(sender, 'first_name', ''),
                        'last_name': getattr(sender, 'last_name', ''),
                        'phone': getattr(sender, 'phone', None),
                        'is_bot': getattr(sender, 'bot', False),
                    },
                    'chat': {
                        'id': getattr(chat, 'id', None),
                        'type': 'private' if hasattr(chat, 'first_name') else 'group',
                        'title': getattr(chat, 'title', None),
                        'username': getattr(chat, 'username', None),
                    }
                }
                
                try:
                    response = requests.post(webhook_url, json=webhook_data, timeout=10)
                    logger.info(f"Webhook enviado para {webhook_url}: {response.status_code}")
                    stats['webhook_calls'] += 1
                    add_system_log('INFO', f'Webhook enviado com sucesso para {webhook_url}', phone)
                except Exception as e:
                    logger.error(f"Erro ao enviar webhook: {e}")
                    add_system_log('ERROR', f'Erro ao enviar webhook: {str(e)}', phone)

            stats['messages_received'] += 1
            add_system_log('INFO', f'Mensagem recebida: {message_text[:50]}...', phone)

        except Exception as e:
            logger.error(f"Erro ao processar mensagem para {phone}: {e}")
            add_system_log('ERROR', f'Erro ao processar mensagem: {str(e)}', phone)

async def connect_and_authorize_client(account_data, client=None, code=None):
    """Conecta e autoriza um cliente Telethon"""
    phone = account_data['phone']
    api_id = account_data['api_id']
    api_hash = account_data['api_hash']
    session_name = f'session_{phone.replace("+", "")}'

    if not client:
        client = TelegramClient(session_name, api_id, api_hash, loop=telethon_loop)

    try:
        await client.connect()
        if not await client.is_user_authorized():
            if code:
                await client.sign_in(phone, code)
            else:
                await client.send_code_request(phone)
                add_system_log('INFO', f'Código SMS enviado para {phone}', phone)
                return {'status': 'pending_verification', 'needs_verification': True, 'phone': phone, 'client_obj': client}
        
        # Se chegou aqui, o cliente esta autorizado
        await setup_client_handlers(client, account_data)
        
        me = await client.get_me()
        account_data['user_id'] = me.id
        account_data['name'] = me.first_name + (f' {me.last_name}' if me.last_name else '')
        account_data['username'] = me.username
        account_data['connected'] = True
        account_data['last_seen'] = datetime.now().isoformat()
        
        telegram_clients[phone] = client
        add_system_log('SUCCESS', f'Conta {phone} conectada como {me.first_name}', phone)
        return {'status': 'success', 'message': 'Conta conectada com sucesso'}
        
    except Exception as e:
        logger.error(f"Erro ao conectar/autorizar cliente Telethon para {phone}: {e}")
        account_data['connected'] = False
        add_system_log('ERROR', f'Erro ao conectar conta: {str(e)}', phone)
        return {'status': 'error', 'error': str(e)}

async def telethon_main():
    """Funcao principal do loop do Telethon"""
    logger.info("Iniciando loop do Telethon...")
    add_system_log('INFO', 'Sistema Telethon iniciado')
    
    # Inicializar clientes existentes
    accounts = load_accounts()
    for account in accounts:
        if account.get('connected', False):
            logger.info(f"Tentando reconectar conta {account['phone']}...")
            try:
                result = await connect_and_authorize_client(account)
                if result['status'] == 'error':
                    logger.error(f"Falha ao reconectar {account['phone']}: {result['error']}")
            except Exception as e:
                logger.error(f"Erro ao reconectar {account['phone']}: {e}")
    
    save_accounts(accounts)
    
    # Manter o loop rodando
    while True:
        await asyncio.sleep(1)

def start_telethon_thread():
    """Inicia o thread do Telethon"""
    global telethon_loop, telethon_thread
    
    def run_telethon():
        global telethon_loop
        telethon_loop = asyncio.new_event_loop()
        asyncio.set_event_loop(telethon_loop)
        telethon_loop.run_until_complete(telethon_main())
    
    telethon_thread = threading.Thread(target=run_telethon, daemon=True)
    telethon_thread.start()
    
    # Aguardar o loop estar pronto
    import time
    time.sleep(2)
    logger.info("Thread do Telethon iniciado")

# --- Funcoes de Agendamento ---

def process_scheduled_messages():
    """Processa mensagens agendadas"""
    try:
        scheduled_messages = load_scheduled_messages()
        current_time = datetime.now()
        
        messages_to_send = []
        remaining_messages = []
        
        for msg in scheduled_messages:
            scheduled_time = datetime.fromisoformat(msg['scheduled_time'])
            if scheduled_time <= current_time:
                messages_to_send.append(msg)
            else:
                remaining_messages.append(msg)
        
        # Enviar mensagens agendadas
        for msg in messages_to_send:
            try:
                async def _send_scheduled():
                    phone = msg['from_account']
                    if phone in telegram_clients:
                        client = telegram_clients[phone]
                        
                        if msg['message_type'] == 'text':
                            await client.send_message(msg['chat_id'], msg['message'])
                        elif msg['message_type'] == 'photo':
                            await client.send_file(msg['chat_id'], msg['file_url'], caption=msg.get('caption'))
                        elif msg['message_type'] == 'video':
                            await client.send_file(msg['chat_id'], msg['file_url'], caption=msg.get('caption'))
                        elif msg['message_type'] == 'audio':
                            await client.send_file(msg['chat_id'], msg['file_url'], caption=msg.get('caption'))
                        elif msg['message_type'] == 'document':
                            await client.send_file(msg['chat_id'], msg['file_url'], caption=msg.get('caption'))
                        
                        stats['messages_sent'] += 1
                        add_system_log('SUCCESS', f'Mensagem agendada enviada para {msg["chat_id"]}', phone)
                
                run_in_telethon_loop(_send_scheduled())
                
            except Exception as e:
                logger.error(f"Erro ao enviar mensagem agendada: {e}")
                add_system_log('ERROR', f'Erro ao enviar mensagem agendada: {str(e)}')
        
        # Salvar mensagens restantes
        save_scheduled_messages(remaining_messages)
        
    except Exception as e:
        logger.error(f"Erro ao processar mensagens agendadas: {e}")

def start_scheduler_thread():
    """Inicia o thread do agendador"""
    global scheduler_thread
    
    def run_scheduler():
        schedule.every(1).minutes.do(process_scheduled_messages)
        while True:
            schedule.run_pending()
            time.sleep(30)
    
    scheduler_thread = threading.Thread(target=run_scheduler, daemon=True)
    scheduler_thread.start()
    logger.info("Thread do agendador iniciado")

def get_client_by_phone(sender_phone=None):
    """Obtem cliente por telefone especifico ou conta ativa"""
    if sender_phone:
        if sender_phone in telegram_clients:
            return telegram_clients[sender_phone]
        else:
            return None
    else:
        # Usar primeira conta conectada
        for phone, client in telegram_clients.items():
            if client.is_connected():
                return client
        return None

# --- Rotas da API ---

@app.route('/')
def dashboard():
    return send_from_directory('static', 'index.html')

@app.route('/static/<path:filename>')
def static_files(filename):
    return send_from_directory('static', filename)

# --- Autenticação ---

@app.route('/api/auth/login', methods=['POST'])
def login():
    data = request.json
    password = data.get('password')
    
    if password == 'Te1234':
        add_system_log('SUCCESS', 'Login realizado com sucesso')
        return jsonify({'status': 'success', 'message': 'Login realizado com sucesso'}), 200
    else:
        add_system_log('WARNING', 'Tentativa de login com senha incorreta')
        return jsonify({'status': 'error', 'error': 'Senha incorreta'}), 401

# --- Status e Logs ---

@app.route('/api/status', methods=['GET'])
def get_status():
    accounts = load_accounts()
    for acc in accounts:
        acc['connected'] = acc['phone'] in telegram_clients and telegram_clients[acc['phone']].is_connected()
    
    return jsonify({
        'status': 'online',
        'accounts': accounts,
        'stats': stats,
        'system_info': {
            'uptime': datetime.now().isoformat(),
            'total_accounts': len(accounts),
            'connected_accounts': len([acc for acc in accounts if acc.get('connected', False)]),
            'telethon_status': 'running' if telethon_loop and telethon_loop.is_running() else 'stopped'
        }
    }), 200

@app.route('/api/logs', methods=['GET'])
def get_logs():
    limit = request.args.get('limit', 100, type=int)
    level = request.args.get('level', None)
    
    logs = list(system_logs)
    
    if level:
        logs = [log for log in logs if log['level'].lower() == level.lower()]
    
    # Retornar os últimos logs
    logs = logs[-limit:]
    
    return jsonify({'logs': logs, 'total': len(logs)}), 200

# --- Gerenciamento de Contas ---

@app.route('/api/accounts', methods=['GET'])
def get_accounts():
    accounts = load_accounts()
    for acc in accounts:
        acc['connected'] = acc['phone'] in telegram_clients and telegram_clients[acc['phone']].is_connected()
    return jsonify({'accounts': accounts}), 200

@app.route('/api/connect-account', methods=['POST'])
def connect_account():
    data = request.json
    phone = data.get('phone')
    api_id = data.get('api_id')
    api_hash = data.get('api_hash')

    if not all([phone, api_id, api_hash]):
        return jsonify({'status': 'error', 'error': 'Dados incompletos'}), 400

    try:
        async def _connect():
            accounts = load_accounts()
            existing_account = next((acc for acc in accounts if acc['phone'] == phone), None)

            if existing_account and existing_account.get('connected'):
                return {'status': 'error', 'error': 'Conta ja conectada'}

            account_data = existing_account or {
                'id': str(uuid.uuid4()),
                'phone': phone,
                'api_id': api_id,
                'api_hash': api_hash,
                'connected': False,
                'name': 'Usuario',
                'username': None,
                'user_id': None,
                'last_seen': None,
                'webhook_url': None
            }

            if not existing_account:
                accounts.append(account_data)
                save_accounts(accounts)

            result = await connect_and_authorize_client(account_data)
            if result['status'] == 'pending_verification':
                pending_verifications[phone] = result.pop('client_obj')
            return result

        result = run_in_telethon_loop(_connect())
        return jsonify(result), 200 if result['status'] != 'error' else 400

    except Exception as e:
        logger.error(f"Erro ao conectar conta {phone}: {e}")
        add_system_log('ERROR', f'Erro ao conectar conta {phone}: {str(e)}')
        return jsonify({'status': 'error', 'error': str(e)}), 500

@app.route('/api/verify-code', methods=['POST'])
def verify_code():
    data = request.json
    phone = data.get('phone')
    code = data.get('code')

    if not all([phone, code]):
        return jsonify({'status': 'error', 'error': 'Telefone e codigo sao obrigatorios'}), 400

    try:
        async def _verify():
            client = pending_verifications.get(phone)
            if not client:
                return {'status': 'error', 'error': 'Nenhuma verificacao pendente para este telefone'}

            accounts = load_accounts()
            account_data = next((acc for acc in accounts if acc['phone'] == phone), None)
            if not account_data:
                return {'status': 'error', 'error': 'Conta nao encontrada'}

            result = await connect_and_authorize_client(account_data, client=client, code=code)
            if result['status'] == 'success':
                del pending_verifications[phone]
                save_accounts(accounts)
            return result

        result = run_in_telethon_loop(_verify())
        return jsonify(result), 200 if result['status'] != 'error' else 400

    except Exception as e:
        logger.error(f"Erro ao verificar codigo para {phone}: {e}")
        add_system_log('ERROR', f'Erro ao verificar código para {phone}: {str(e)}')
        return jsonify({'status': 'error', 'error': str(e)}), 500

@app.route('/api/remove-account', methods=['DELETE'])
def remove_account():
    data = request.json
    phone = data.get('phone')

    if not phone:
        return jsonify({'status': 'error', 'error': 'Telefone é obrigatório'}), 400

    try:
        async def _remove():
            if phone in telegram_clients:
                client = telegram_clients.pop(phone)
                await client.disconnect()
                logger.info(f"Cliente Telethon para {phone} desconectado")

        if phone in telegram_clients:
            run_in_telethon_loop(_remove())

        accounts = load_accounts()
        initial_len = len(accounts)
        accounts = [acc for acc in accounts if acc['phone'] != phone]
        save_accounts(accounts)

        if len(accounts) == initial_len:
            return jsonify({'status': 'error', 'error': 'Conta nao encontrada'}), 404

        # Remover arquivo de sessao
        session_file = f'session_{phone.replace("+", "")}.session'
        if os.path.exists(session_file):
            os.remove(session_file)

        add_system_log('SUCCESS', f'Conta {phone} removida com sucesso')
        return jsonify({'status': 'success', 'message': f'Conta {phone} removida com sucesso'}), 200

    except Exception as e:
        logger.error(f"Erro ao remover conta {phone}: {e}")
        add_system_log('ERROR', f'Erro ao remover conta {phone}: {str(e)}')
        return jsonify({'status': 'error', 'error': str(e)}), 500

# --- Envio de Mensagens ---

@app.route('/api/send-message', methods=['POST'])
def send_message():
    data = request.json
    chat_id = data.get('chat_id')
    message = data.get('message')
    from_account = data.get('from_account')

    if not all([chat_id, message]):
        return jsonify({'status': 'error', 'error': 'Chat ID e mensagem sao obrigatorios'}), 400

    try:
        async def _send():
            client = get_client_by_phone(from_account)
            if not client:
                return {'status': 'error', 'error': 'Nenhuma conta conectada disponível'}

            try:
                chat_id_int = int(chat_id)
            except ValueError:
                chat_id_int = chat_id

            await client.send_message(chat_id_int, message)
            stats['messages_sent'] += 1
            
            phone = from_account or 'conta ativa'
            add_system_log('SUCCESS', f'Mensagem enviada via {phone} para {chat_id}')
            
            return {'status': 'success', 'message': 'Mensagem enviada com sucesso', 'from_account': from_account}

        result = run_in_telethon_loop(_send())
        return jsonify(result), 200 if result['status'] != 'error' else 401

    except Exception as e:
        logger.error(f"Erro ao enviar mensagem: {e}")
        add_system_log('ERROR', f'Erro ao enviar mensagem: {str(e)}')
        return jsonify({'status': 'error', 'error': str(e)}), 500

@app.route('/api/send-photo', methods=['POST'])
def send_photo():
    data = request.json
    chat_id = data.get('chat_id')
    photo_url = data.get('photo_url')
    caption = data.get('caption', None)
    from_account = data.get('from_account')

    if not all([chat_id, photo_url]):
        return jsonify({'status': 'error', 'error': 'Chat ID e URL da foto sao obrigatorios'}), 400

    try:
        async def _send():
            client = get_client_by_phone(from_account)
            if not client:
                return {'status': 'error', 'error': 'Nenhuma conta conectada disponível'}

            try:
                chat_id_int = int(chat_id)
            except ValueError:
                chat_id_int = chat_id

            await client.send_file(chat_id_int, photo_url, caption=caption)
            stats['messages_sent'] += 1
            
            phone = from_account or 'conta ativa'
            add_system_log('SUCCESS', f'Foto enviada via {phone} para {chat_id}')
            
            return {'status': 'success', 'message': 'Foto enviada com sucesso', 'from_account': from_account}

        result = run_in_telethon_loop(_send())
        return jsonify(result), 200 if result['status'] != 'error' else 401

    except Exception as e:
        logger.error(f"Erro ao enviar foto: {e}")
        add_system_log('ERROR', f'Erro ao enviar foto: {str(e)}')
        return jsonify({'status': 'error', 'error': str(e)}), 500

@app.route('/api/send-video', methods=['POST'])
def send_video():
    data = request.json
    chat_id = data.get('chat_id')
    video_url = data.get('video_url')
    caption = data.get('caption', None)
    from_account = data.get('from_account')

    if not all([chat_id, video_url]):
        return jsonify({'status': 'error', 'error': 'Chat ID e URL do video sao obrigatorios'}), 400

    try:
        async def _send():
            client = get_client_by_phone(from_account)
            if not client:
                return {'status': 'error', 'error': 'Nenhuma conta conectada disponível'}

            try:
                chat_id_int = int(chat_id)
            except ValueError:
                chat_id_int = chat_id

            await client.send_file(chat_id_int, video_url, caption=caption)
            stats['messages_sent'] += 1
            
            phone = from_account or 'conta ativa'
            add_system_log('SUCCESS', f'Vídeo enviado via {phone} para {chat_id}')
            
            return {'status': 'success', 'message': 'Video enviado com sucesso', 'from_account': from_account}

        result = run_in_telethon_loop(_send())
        return jsonify(result), 200 if result['status'] != 'error' else 401

    except Exception as e:
        logger.error(f"Erro ao enviar video: {e}")
        add_system_log('ERROR', f'Erro ao enviar vídeo: {str(e)}')
        return jsonify({'status': 'error', 'error': str(e)}), 500

@app.route('/api/send-audio', methods=['POST'])
def send_audio():
    data = request.json
    chat_id = data.get('chat_id')
    audio_url = data.get('audio_url')
    caption = data.get('caption', None)
    from_account = data.get('from_account')

    if not all([chat_id, audio_url]):
        return jsonify({'status': 'error', 'error': 'Chat ID e URL do audio sao obrigatorios'}), 400

    try:
        async def _send():
            client = get_client_by_phone(from_account)
            if not client:
                return {'status': 'error', 'error': 'Nenhuma conta conectada disponível'}

            try:
                chat_id_int = int(chat_id)
            except ValueError:
                chat_id_int = chat_id

            await client.send_file(chat_id_int, audio_url, caption=caption)
            stats['messages_sent'] += 1
            
            phone = from_account or 'conta ativa'
            add_system_log('SUCCESS', f'Áudio enviado via {phone} para {chat_id}')
            
            return {'status': 'success', 'message': 'Audio enviado com sucesso', 'from_account': from_account}

        result = run_in_telethon_loop(_send())
        return jsonify(result), 200 if result['status'] != 'error' else 401

    except Exception as e:
        logger.error(f"Erro ao enviar audio: {e}")
        add_system_log('ERROR', f'Erro ao enviar áudio: {str(e)}')
        return jsonify({'status': 'error', 'error': str(e)}), 500

@app.route('/api/send-document', methods=['POST'])
def send_document():
    data = request.json
    chat_id = data.get('chat_id')
    document_url = data.get('document_url')
    caption = data.get('caption', None)
    from_account = data.get('from_account')

    if not all([chat_id, document_url]):
        return jsonify({'status': 'error', 'error': 'Chat ID e URL do documento sao obrigatorios'}), 400

    try:
        async def _send():
            client = get_client_by_phone(from_account)
            if not client:
                return {'status': 'error', 'error': 'Nenhuma conta conectada disponível'}

            try:
                chat_id_int = int(chat_id)
            except ValueError:
                chat_id_int = chat_id

            await client.send_file(chat_id_int, document_url, caption=caption)
            stats['messages_sent'] += 1
            
            phone = from_account or 'conta ativa'
            add_system_log('SUCCESS', f'Documento enviado via {phone} para {chat_id}')
            
            return {'status': 'success', 'message': 'Documento enviado com sucesso', 'from_account': from_account}

        result = run_in_telethon_loop(_send())
        return jsonify(result), 200 if result['status'] != 'error' else 401

    except Exception as e:
        logger.error(f"Erro ao enviar documento: {e}")
        add_system_log('ERROR', f'Erro ao enviar documento: {str(e)}')
        return jsonify({'status': 'error', 'error': str(e)}), 500

# --- Agendamento de Mensagens ---

@app.route('/api/schedule-message', methods=['POST'])
def schedule_message():
    data = request.json
    chat_id = data.get('chat_id')
    message = data.get('message')
    scheduled_time = data.get('scheduled_time')  # ISO format
    from_account = data.get('from_account')
    message_type = data.get('message_type', 'text')  # text, photo, video, audio, document
    file_url = data.get('file_url')  # Para mídia
    caption = data.get('caption')

    if not all([chat_id, scheduled_time, from_account]):
        return jsonify({'status': 'error', 'error': 'Chat ID, horário agendado e conta são obrigatórios'}), 400

    if message_type == 'text' and not message:
        return jsonify({'status': 'error', 'error': 'Mensagem é obrigatória para tipo texto'}), 400
    
    if message_type != 'text' and not file_url:
        return jsonify({'status': 'error', 'error': 'URL do arquivo é obrigatória para mídia'}), 400

    try:
        # Validar formato da data
        scheduled_datetime = datetime.fromisoformat(scheduled_time)
        if scheduled_datetime <= datetime.now():
            return jsonify({'status': 'error', 'error': 'Horário agendado deve ser no futuro'}), 400

        scheduled_messages = load_scheduled_messages()
        
        new_message = {
            'id': str(uuid.uuid4()),
            'chat_id': chat_id,
            'message': message,
            'message_type': message_type,
            'file_url': file_url,
            'caption': caption,
            'scheduled_time': scheduled_time,
            'from_account': from_account,
            'created_at': datetime.now().isoformat(),
            'status': 'pending'
        }
        
        scheduled_messages.append(new_message)
        save_scheduled_messages(scheduled_messages)
        
        stats['scheduled_messages'] += 1
        add_system_log('SUCCESS', f'Mensagem agendada para {scheduled_time} via {from_account}')
        
        return jsonify({
            'status': 'success', 
            'message': 'Mensagem agendada com sucesso',
            'scheduled_id': new_message['id']
        }), 200

    except Exception as e:
        logger.error(f"Erro ao agendar mensagem: {e}")
        add_system_log('ERROR', f'Erro ao agendar mensagem: {str(e)}')
        return jsonify({'status': 'error', 'error': str(e)}), 500

@app.route('/api/scheduled-messages', methods=['GET'])
def get_scheduled_messages():
    try:
        scheduled_messages = load_scheduled_messages()
        return jsonify({'scheduled_messages': scheduled_messages}), 200
    except Exception as e:
        logger.error(f"Erro ao obter mensagens agendadas: {e}")
        return jsonify({'status': 'error', 'error': str(e)}), 500

@app.route('/api/scheduled-messages/<message_id>', methods=['DELETE'])
def cancel_scheduled_message(message_id):
    try:
        scheduled_messages = load_scheduled_messages()
        initial_len = len(scheduled_messages)
        
        scheduled_messages = [msg for msg in scheduled_messages if msg['id'] != message_id]
        
        if len(scheduled_messages) == initial_len:
            return jsonify({'status': 'error', 'error': 'Mensagem agendada não encontrada'}), 404
        
        save_scheduled_messages(scheduled_messages)
        add_system_log('SUCCESS', f'Mensagem agendada {message_id} cancelada')
        
        return jsonify({'status': 'success', 'message': 'Mensagem agendada cancelada'}), 200
    
    except Exception as e:
        logger.error(f"Erro ao cancelar mensagem agendada: {e}")
        return jsonify({'status': 'error', 'error': str(e)}), 500

# --- Webhooks ---

@app.route('/api/set-webhook', methods=['POST'])
def set_webhook():
    data = request.json
    webhook_url = data.get('webhook_url', '')
    account_phone = data.get('account_phone')  # Opcional - para webhook individual
    
    config = load_config()
    
    if account_phone:
        # Webhook individual para conta específica
        if 'accounts_webhooks' not in config:
            config['accounts_webhooks'] = {}
        config['accounts_webhooks'][account_phone] = webhook_url
        add_system_log('SUCCESS', f'Webhook individual configurado para {account_phone}')
    else:
        # Webhook global
        config['webhook_url'] = webhook_url
        add_system_log('SUCCESS', f'Webhook global configurado: {webhook_url}')
    
    save_config(config)
    
    return jsonify({'status': 'success', 'message': 'Webhook configurado com sucesso'}), 200

@app.route('/api/webhooks', methods=['GET'])
def get_webhooks():
    config = load_config()
    
    webhooks = {
        'global_webhook': config.get('webhook_url', ''),
        'account_webhooks': config.get('accounts_webhooks', {})
    }
    
    return jsonify({'webhooks': webhooks}), 200

# --- Gerenciamento de Grupos ---

@app.route('/api/create-group', methods=['POST'])
def create_group():
    data = request.json
    group_name = data.get('group_name')
    description = data.get('description', '')
    from_account = data.get('from_account')

    if not all([group_name, from_account]):
        return jsonify({'status': 'error', 'error': 'Nome do grupo e conta são obrigatórios'}), 400

    try:
        async def _create_group():
            client = get_client_by_phone(from_account)
            if not client:
                return {'status': 'error', 'error': 'Conta não encontrada ou não conectada'}

            # Criar grupo/canal
            result = await client(CreateChannelRequest(
                title=group_name,
                about=description,
                megagroup=True  # Criar como supergrupo
            ))
            
            group_id = result.chats[0].id
            stats['groups_created'] += 1
            add_system_log('SUCCESS', f'Grupo "{group_name}" criado via {from_account}')
            
            return {
                'status': 'success', 
                'message': 'Grupo criado com sucesso',
                'group_id': group_id,
                'group_name': group_name
            }

        result = run_in_telethon_loop(_create_group())
        return jsonify(result), 200 if result['status'] != 'error' else 400

    except Exception as e:
        logger.error(f"Erro ao criar grupo: {e}")
        add_system_log('ERROR', f'Erro ao criar grupo: {str(e)}')
        return jsonify({'status': 'error', 'error': str(e)}), 500

@app.route('/api/add-to-group', methods=['POST'])
def add_to_group():
    data = request.json
    group_id = data.get('group_id')
    user_ids = data.get('user_ids', [])  # Lista de IDs de usuários
    usernames = data.get('usernames', [])  # Lista de usernames
    phone_numbers = data.get('phone_numbers', [])  # Lista de telefones
    from_account = data.get('from_account')

    if not all([group_id, from_account]):
        return jsonify({'status': 'error', 'error': 'ID do grupo e conta são obrigatórios'}), 400

    if not any([user_ids, usernames, phone_numbers]):
        return jsonify({'status': 'error', 'error': 'Pelo menos uma lista de usuários deve ser fornecida'}), 400

    try:
        async def _add_to_group():
            client = get_client_by_phone(from_account)
            if not client:
                return {'status': 'error', 'error': 'Conta não encontrada ou não conectada'}

            try:
                group_id_int = int(group_id)
            except ValueError:
                group_id_int = group_id

            added_users = []
            failed_users = []

            # Adicionar por user_ids
            for user_id in user_ids:
                try:
                    await client(InviteToChannelRequest(
                        channel=group_id_int,
                        users=[InputPeerUser(user_id, 0)]
                    ))
                    added_users.append(f"ID:{user_id}")
                    stats['leads_added'] += 1
                except Exception as e:
                    failed_users.append(f"ID:{user_id} - {str(e)}")

            # Adicionar por usernames
            for username in usernames:
                try:
                    user = await client.get_entity(username)
                    await client(InviteToChannelRequest(
                        channel=group_id_int,
                        users=[user]
                    ))
                    added_users.append(f"@{username}")
                    stats['leads_added'] += 1
                except Exception as e:
                    failed_users.append(f"@{username} - {str(e)}")

            # Adicionar por telefones
            for phone in phone_numbers:
                try:
                    user = await client.get_entity(phone)
                    await client(InviteToChannelRequest(
                        channel=group_id_int,
                        users=[user]
                    ))
                    added_users.append(phone)
                    stats['leads_added'] += 1
                except Exception as e:
                    failed_users.append(f"{phone} - {str(e)}")

            add_system_log('SUCCESS', f'{len(added_users)} usuários adicionados ao grupo {group_id} via {from_account}')
            
            return {
                'status': 'success',
                'message': f'{len(added_users)} usuários adicionados com sucesso',
                'added_users': added_users,
                'failed_users': failed_users,
                'total_added': len(added_users),
                'total_failed': len(failed_users)
            }

        result = run_in_telethon_loop(_add_to_group())
        return jsonify(result), 200

    except Exception as e:
        logger.error(f"Erro ao adicionar usuários ao grupo: {e}")
        add_system_log('ERROR', f'Erro ao adicionar usuários ao grupo: {str(e)}')
        return jsonify({'status': 'error', 'error': str(e)}), 500

if __name__ == '__main__':
    # Carregar logs do sistema
    load_system_logs()
    add_system_log('INFO', 'Sistema iniciado')
    
    # Iniciar threads
    start_telethon_thread()
    start_scheduler_thread()
    
    # Iniciar Flask
    logger.info("Iniciando servidor Flask...")
    add_system_log('INFO', 'Servidor Flask iniciado na porta 5000')
    app.run(host='0.0.0.0', port=5000, debug=False)

